#ifndef __GAME_H__
#define __GAME_H__

void game();
#endif