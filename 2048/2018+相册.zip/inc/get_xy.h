/***********************************************************
-  Copyright (C), Ksd xiongzh
-  Filename  : get_xy.h
-  Author  :  xiongzh		Date:  2019-8-1
-  Description  :  
				  1、对get_xy.c文件内的函数进行声明
-  Others  :	none
-  Function List  :  
   1.  get_xy() ： 获取坐标
*************************************************************/

#ifndef __GET_XY_H__
#define __GET_XY_H__

//void get_xy(int *x1,int *x2,int *x,int *y,int *y1,int *y2);
void get_xy(int* x,int* y);

#endif