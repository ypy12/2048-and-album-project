/***********************************************************
-  Copyright (C), Ksd xiongzh
-  Filename  : inlist.h
-  Author  :  xiongzh		Date:  2019-8-1
-  Description  :  
				  1、对inlist.c文件内的函数进行声明
-  Others  :	none
-  Function List  :  
   1.  inlist() ： 把图片名插入链表
*************************************************************/

#ifndef __INLIST_H__
#define __INLIST_H__
#include "list.h"
PTO inlist(PTO head,char *d_name,char *argv);

#endif