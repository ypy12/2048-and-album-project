#ifndef __GAME_H__
#define __GAME_H__

int xiangce();
#endif